package com.fctech.manager.dao;

/**
 * Created by joe on 15/6/11.
 */
public class User {
}
